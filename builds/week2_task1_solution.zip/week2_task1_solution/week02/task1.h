//
// Created by Valeriy Chevtaev on 11/4/13.
// Copyright (c) 2013 7bit. All rights reserved.
//



#ifndef __week02_task1_H_
#define __week02_task1_H_

namespace week02 {

class task1 {
public:
    // Simulation: Run few tests on randomly generated graphs
    void run();
};

};


#endif //__week02_task1_H_
