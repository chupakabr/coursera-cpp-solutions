//
//  main.cpp
//  CourseraCpp
//
//  Created by Valeriy Chevtaev on 10/17/13.
//  Copyright (c) 2013 7bit. All rights reserved.
//

#include <iostream>
#include "week02/task1.h"

using namespace week02;

int main(int argc, const char * argv[])
{
    std::cout << "Coursera solutions." << std::endl;

    task1 app;
    app.run();

    std::cout << "Done." << std::endl;
    return 0;
}
